import java.util.ArrayList;

public class Armazem{
    public static ArrayList<Custo> listaGastos = new ArrayList<>();
    public static ArrayList<Lucro> listaGanhos = new ArrayList<>();

    public static void adicionarGasto(Custo gasto) {
        listaGastos.add(gasto);
    }

    public static void adicionarGanho(Lucro ganho) {
        listaGanhos.add(ganho);
    }

    public static void gerarRelatorioGasto(){
        double total = 0.0;
        System.out.println();
        System.out.println("Relatório de gastos");
        System.out.println("---------------------");
        for (Custo gasto : listaGastos) {
            System.out.println("Tipo: " + gasto.getTipo());
            System.out.println("Data: " + gasto.getData());
            System.out.println("Valor: " + gasto.getValor());
            System.out.println("Forma de Pagamento: " + gasto.getFormaPag());
            System.out.println();
            total += gasto.getValor();
        }
        System.out.println("Total: "+ total);
        System.out.println();
    }

    public static void gerarRelatorioGanho(){
        double total = 0.0;
        System.out.println();
        System.out.println("Relatório de ganhos");
        System.out.println("---------------------");
        for (Lucro ganho : listaGanhos) {
            System.out.println("Tipo: " + ganho.getTipo());
            System.out.println("Data: " + ganho.getData());
            System.out.println("Valor: " + ganho.getValor());
            System.out.println();
            total += ganho.getValor();
        }
        System.out.println("Total: " + total);
    }

    public static void gerarRelatorioMensal() {
        double totalGanhos = 0.0;
        double totalGastos = 0.0;
        for (Lucro ganho : listaGanhos) {
            totalGanhos += ganho.getValor();
        }
        for (Custo gasto : listaGastos) {
            totalGastos += gasto.getValor();
        }
        double saldo = totalGanhos - totalGastos;
        System.out.println();
        System.out.println("Relatório Mensal");
        System.out.println("-------------------------");
        System.out.println("Total de Receitas: R$" + totalGanhos);
        System.out.println("Total de Despesas: R$" + totalGastos);
        System.out.println("Saldo: R$" + saldo);
        System.out.println();
    }

}
