public class Custo {
    private String TpCusto;
    private String DtCusto;
    private double VlCusto;
    private String FrPagamento;
    public Custo(String  TpCusto, String DtCusto, double VlCusto, String FrPagamento) {
        this.TpCusto = TpCusto;
        this.DtCusto = DtCusto;
        this.VlCusto= VlCusto;
        this.FrPagamento = FrPagamento;
    }
    public String  getTipo(){
        return TpCusto;
    }
    public String getData() {
        return DtCusto;
    }
    public double getValor() {
        return VlCusto;
    }
    public String getFormaPag() {
        return FrPagamento;
    }
}