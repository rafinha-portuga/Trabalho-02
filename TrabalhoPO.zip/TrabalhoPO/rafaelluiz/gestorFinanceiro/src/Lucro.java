public class Lucro {
    private String TpLucro;
    private String DtLucro;
    private double VlLucro;

    public Lucro(String TpLucro, String DtLucro, double VlLucro){
        this.TpLucro = TpLucro;
        this.DtLucro = DtLucro;
        this.VlLucro= VlLucro;
    }
    public String getTipo() {
        return TpLucro;
    }

    public String getData() {
        return DtLucro;
    }


    public double getValor() {
        return VlLucro;
    }

}