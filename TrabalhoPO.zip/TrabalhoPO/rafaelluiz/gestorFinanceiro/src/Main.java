import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int opcaoOperacional = 0;

        while (opcaoOperacional != 6) {
            Menus.telaInicial();
            opcaoOperacional = Integer.parseInt(input.nextLine());

            switch (opcaoOperacional) {
                case 1:
                    Menus.telaTipoGasto();
                    String TpCusto = input.nextLine();
                    if ("99".equals(TpCusto)){
                        System.out.println("Operação Cancelada.Voltando à tela inicial.... ");
                        System.out.println();
                        break;
                    }
                    Menus.telaData();
                    String data = input.nextLine();

                    Menus.telaValor();
                    double valor = Double.parseDouble(input.nextLine());

                    Menus.telaFormaPagamento();
                    String tipoPag = input.nextLine();

                    Custo gasto = new Custo(TpCusto,data,valor,tipoPag);
                    Armazem.adicionarGasto(gasto);
                    break;
                case 2:
                    Menus.telaTipoGanho();
                    String TpLucro = input.nextLine();
                    if (TpLucro == "99"){
                        break;
                    }

                    Menus.telaData();
                    String DtLucro = input.nextLine();

                    Menus.telaValor();
                    double VlLucro = Double.parseDouble(input.nextLine());

                    Lucro ganho = new Lucro(TpLucro,DtLucro,VlLucro);
                    Armazem.adicionarGanho(ganho);
                    break;
                case 3:
                    Armazem.gerarRelatorioGasto();
                    break;
                case 4:
                    Armazem.gerarRelatorioGanho();
                    break;
                case 5:
                    Armazem.gerarRelatorioMensal();
                    break;
                case 6:
                    System.out.println("Saindo do programa...");
                    break;
                default:
                    System.out.println("[ERRO] Opção inválida! Tente novamente.");
                    System.out.println();
            }
        }
    }
}